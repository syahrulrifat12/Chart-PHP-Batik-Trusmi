/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 10.4.19-MariaDB : Database - test_programmer
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`test_programmer` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `test_programmer`;

/*Table structure for table `tbl_bobot_kpi_marketing` */

DROP TABLE IF EXISTS `tbl_bobot_kpi_marketing`;

CREATE TABLE `tbl_bobot_kpi_marketing` (
  `kpi` varchar(50) DEFAULT NULL,
  `target` int(11) DEFAULT NULL,
  `bobot` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tbl_bobot_kpi_marketing` */

insert  into `tbl_bobot_kpi_marketing`(`kpi`,`target`,`bobot`) values 
('Sales',2,'50%'),
('Report',2,'50%');

/*Table structure for table `tbl_kpi_marketing` */

DROP TABLE IF EXISTS `tbl_kpi_marketing`;

CREATE TABLE `tbl_kpi_marketing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasklist` varchar(100) DEFAULT NULL,
  `kpi` varchar(100) DEFAULT NULL,
  `karyawan` varchar(100) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `aktual` date DEFAULT NULL,
  `hasil_aktual` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_kpi_marketing` */

insert  into `tbl_kpi_marketing`(`id`,`tasklist`,`kpi`,`karyawan`,`deadline`,`aktual`,`hasil_aktual`) values 
(1,'Tasklist 1','Sales','Budi','2022-01-10','2022-01-09',2),
(2,'Tasklist 2','Sales','Budi','2022-01-10','2022-01-08',2),
(3,'Tasklist 3','Report','Budi','2022-01-10','2022-01-07',2),
(4,'Tasklist 4','Report','Budi','2022-01-10','2022-01-12',1),
(5,'Tasklist 5','Sales','Adi','2022-01-10','2022-01-09',2),
(6,'Tasklist 6','Sales','Adi','2022-01-10','2022-01-12',1),
(7,'Tasklist 7','Report','Adi','2022-01-10','2022-01-07',2),
(8,'Tasklist 8','Report','Adi','2022-01-10','2022-01-07',2),
(9,'Tasklist 9','Sales','Rara','2022-01-10','2022-01-12',1),
(10,'Tasklist 10','Sales','Rara','2022-01-10','2022-01-09',2),
(11,'Tasklist 11','Report','Rara','2022-01-10','2022-01-12',1),
(12,'Tasklist 12','Report','Doni','2022-01-10','2022-01-09',2),
(13,'Tasklist 13','Sales','Doni','2022-01-10','2022-01-12',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
