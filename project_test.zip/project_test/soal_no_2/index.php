<!DOCTYPE html>
<html>

<head>
    <script src="js/Chart.js"></script>
</head>

<body>
    <br>
    <h4>Data Menghitung Jumlah Tasklist </h4>
    <canvas id="myChart"></canvas>
    <?php
    // Koneksikan ke database
    $kon = mysqli_connect("localhost", "root", "", "test_programmer");
    //Inisialisasi nilai variabel awal
    $nama_jurusan = "";
    $jumlah = null;
    //Query SQL
    // $sql = "select tasklist,COUNT(*) as 'total' from tbl_kpi_marketing GROUP by karyawan";
    $sql = "SELECT a.karyawan AS Nama,COUNT(*) AS jumlah_tasklist,CASE a.karyawan 
    WHEN a.aktual <= deadline THEN 'Ontime'
    WHEN a.aktual > deadline THEN 'Late'
    ELSE a.karyawan
END AS leadtime,((a.hasil_aktual)/(b.target) * 100)AS persentase 
FROM tbl_kpi_marketing a JOIN tbl_bobot_kpi_marketing b ON a.kpi=b.kpi 
GROUP BY a.karyawan";
    $hasil = mysqli_query($kon, $sql);

    while ($data = mysqli_fetch_array($hasil)) {
        //Mengambil nilai jurusan dari database
        $jur = $data['Nama'];
        $nama_jurusan .= "'$jur'" . ", ";
        //Mengambil nilai total dari database
        $jum = $data['jumlah_tasklist'];
        $jumlah .= "$jum" . ", ";
    }
    ?>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            // The type of chart we want to create
            type: 'bar',
            // The data for our dataset
            data: {
                labels: [<?php echo $nama_jurusan; ?>],
                datasets: [{
                    label: 'Data Jumlah Tasklist ',
                    backgroundColor: ['rgb(255, 99, 132)', 'rgba(56, 86, 255, 0.87)', 'rgb(60, 179, 113)', 'rgb(175, 238, 239)'],
                    borderColor: ['rgb(255, 99, 132)'],
                    data: [<?php echo $jumlah; ?>]
                }]
            },

            // Configuration options go here
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
</body>

</html>